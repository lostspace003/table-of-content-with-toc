@echo off
rem Makes a new editable Word document with the Gennoor watermark: "New document - Gennoor.docx" in this folder.
setlocal
set "PY=%~dp0..\_recording\tools\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=py -3"
%PY% "%~dp0gennoor_watermark.py" --blank "%~dp0New document - Gennoor.docx"
pause
