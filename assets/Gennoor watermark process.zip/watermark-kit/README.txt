GENNOOR WATERMARK KIT
=====================

The mark: the Gennoor Tech logo, big and very light, diagonal across the page, with
"For more info - https://gennoor.com" under it.

USE IT
------
1. Watermark and lock.bat - drag one or more PDF or Word (.docx) files onto it.
   For each file it writes, next to the original (the original is not changed):
     <name> - Gennoor.pdf   every page flattened to an image with the mark, locked.
                            No software can edit the text - it is a picture. Copy and search
                            still work through a hidden text layer. Printing is allowed.
     <name> - Gennoor.docx  (Word files only) the mark behind the text on every page,
                            "Restrict editing: read only" with a random password nobody has.
   Send the PDF when it must not be edited. A Word file can always be unlocked by someone
   determined, so the locked .docx is only a deterrent.

2. Gennoor - Blank document (A4).docx / (Letter).docx - start new documents from these.
   They are editable; the mark sits in the header, behind the text, on every page.
   When the document is final, drag it onto "Watermark and lock.bat".
   (Make blank document.bat makes a fresh A4 copy.)

3. Gennoor watermark - A4.png / Letter.png / A4 landscape.png - the mark as a transparent
   picture, for other tools (PowerPoint, Canva...): place it full page, behind the content.

4. gennoor-logo.png / gennoor-logo.svg - the logo itself.

NEEDS
-----
Python with: pip install pymupdf pillow python-docx pywin32   (Word to PDF uses Microsoft Word).
The .bat files use the course tools' Python automatically when this folder sits in "AI-103 Labs".

To change how light the mark is: open gennoor_watermark.py and edit LOGO_ALPHA / TEXT_ALPHA.
