@echo off
rem Drag one or more PDF or Word (.docx) files onto this file.
rem Writes "<name> - Gennoor.pdf" (flattened + locked) and, for Word, "<name> - Gennoor.docx" (read-only) next to each.
setlocal
set "PY=%~dp0..\_recording\tools\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=py -3"
if "%~1"=="" (
  echo Drag PDF or Word files onto this file.
  pause
  exit /b
)
%PY% "%~dp0gennoor_watermark.py" %*
echo.
echo Done.
pause
