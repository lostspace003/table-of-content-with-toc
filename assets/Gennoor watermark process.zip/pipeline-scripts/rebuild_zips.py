"""rebuild_zips.py - harden the Udemy resource zips in "AI103 - Course Pilot" (owner, 2026-10-07).

1. Slides and guides (every PDF under Guides/, Slides/ and the Getting started zip): PICTURE-ONLY pages - the
   watermarked page image is kept, the invisible text layer is dropped (nothing to copy or convert to clean text),
   encrypted with print-only permissions.
2. Lab sample data (PDF/DOCX inputs the labs send to Azure): the ORIGINAL, unwatermarked file from module-N/ (so the
   labs give the same results as the videos).
3. Code and everything else: unchanged.
Only the zips are rewritten (the hard-linked videos are not touched, safe while Course Pilot runs).
    python rebuild_zips.py
"""
import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parent))  # noqa: E702
from course import CODE, SHORT, ROOT, REC, LABS, VIDEO, UDEMY, UDEMY_QUIZ, UDEMY_RES, UDEMY_PKG, PILOT, COURSE_DIR, LECTURES, VOICE  # noqa: E402,F401
import io
import re
import secrets
import zipfile
from pathlib import Path

import pymupdf

HERE = Path(__file__).resolve().parent
LABS = LABS
PILOT = PILOT


def picture_only(data: bytes) -> bytes:
    src = pymupdf.open(stream=data, filetype="pdf")
    out = pymupdf.open()
    for page in src:
        imgs = page.get_images(full=True)
        np_ = out.new_page(width=page.rect.width, height=page.rect.height)
        if len(imgs) == 1:                                   # flattened page: reuse its image as is
            np_.insert_image(np_.rect, stream=src.extract_image(imgs[0][0])["image"])
        else:                                                # anything else: render it
            np_.insert_image(np_.rect, pixmap=page.get_pixmap(dpi=200))
    buf = io.BytesIO()
    out.save(buf, garbage=3, deflate=True, encryption=pymupdf.PDF_ENCRYPT_AES_256,
             owner_pw=secrets.token_urlsafe(24), user_pw="",
             permissions=pymupdf.PDF_PERM_PRINT | pymupdf.PDF_PERM_PRINT_HQ)
    return buf.getvalue()


def originals(mod: int) -> dict:
    """file name -> original lab data file (PDF/DOCX) under module-N/ (not the guides)"""
    base = LABS / f"module-{mod}"
    out = {}
    for f in base.rglob("*"):
        if f.suffix.lower() in (".pdf", ".docx") and "data" in [p.lower() for p in f.parts]:
            out.setdefault(f.name, f)
    return out


def main():
    for z in sorted(PILOT.glob("AI-103 - *.zip")):
        m = re.search(r"Module (\d) materials", z.name)
        orig = originals(int(m.group(1))) if m else {}
        src = zipfile.ZipFile(z)
        tmp = z.with_suffix(".tmp")
        stats = {"picture-only": 0, "original data": 0, "unchanged": 0}
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as dst:
            for info in src.infolist():
                if info.is_dir():
                    continue
                data = src.read(info)
                name = info.filename
                parts = name.split("/")
                low = name.lower()
                if low.endswith(".pdf") and ("/guides/" in low or "/slides/" in low or not m):
                    data, k = picture_only(data), "picture-only"
                elif parts[-1] in orig:
                    data, k = orig[parts[-1]].read_bytes(), "original data"
                else:
                    k = "unchanged"
                stats[k] += 1
                dst.writestr(name, data)
        src.close()
        tmp.replace(z)
        print(z.name, stats)


if __name__ == "__main__":
    main()
