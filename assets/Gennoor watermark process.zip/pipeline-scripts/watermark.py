"""Gennoor watermark: a big, very light, diagonal logo + "For more info - https://gennoor.com".

PDF  -> flattened (every page becomes an image with the mark, plus an invisible text layer so copy and search still
        work), then locked: printing and copying allowed, editing not (random owner password, no open password).
        mode "overlay" keeps the original page and only adds the mark + lock (for data files read by search).
DOCX -> the mark as a picture behind the text in every header, document locked read-only (random password);
        plus a flattened, locked PDF copy - the only form no software can edit.

Usage:  python watermark.py <file.pdf|file.docx> [...]       -> "<name> - Gennoor.pdf" / ".docx" next to each file
        python watermark.py --blank <out.docx>                 -> editable blank document with the mark
In code: stamp_bytes(pdf_bytes, mode="flatten"|"overlay"), stamp_docx(src, dst, lock=True)
"""
import copy
import io
import math
import secrets
import sys
from functools import lru_cache
from pathlib import Path

import pymupdf
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
LOGO = next(p for p in [HERE / "brand" / "gennoor-logo.png", HERE / "gennoor-logo.png"] if p.exists())
SITE = "For more info - https://gennoor.com"
LOGO_ALPHA = 0.075   # very light, but there
TEXT_ALPHA = 0.16
TEXT_RGB = (74, 85, 104)
PX_PER_PT = 2        # raster resolution of the mark
FLAT_DPI = 200       # resolution of flattened pages
FONT = next((f for f in ["C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/arial.ttf",
                         "/System/Library/Fonts/Helvetica.ttc", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
             if Path(f).exists()), None)


def _faint(img, alpha):
    img = img.copy()
    img.putalpha(img.getchannel("A").point(lambda v: int(v * alpha)))
    return img


@lru_cache(maxsize=8)
def overlay(w_pt, h_pt):
    """PNG bytes of the diagonal mark for a page of w_pt x h_pt points (transparent background)."""
    W, H = int(w_pt * PX_PER_PT), int(h_pt * PX_PER_PT)
    logo = Image.open(LOGO).convert("RGBA")
    logo = logo.crop(logo.getchannel("A").getbbox())
    lw = int(math.hypot(W, H) * 0.62)            # big: ~62% of the page diagonal
    logo = logo.resize((lw, int(logo.height * lw / logo.width)), Image.LANCZOS)
    size = int(lw * 0.045)
    font = ImageFont.truetype(FONT, size) if FONT else ImageFont.load_default(size)
    tb = ImageDraw.Draw(logo).textbbox((0, 0), SITE, font=font)
    tw, th = tb[2] - tb[0], tb[3] - tb[1]
    gap = int(logo.height * 0.18)
    block = Image.new("RGBA", (lw, logo.height + gap + th + 10), (0, 0, 0, 0))
    block.alpha_composite(_faint(logo, LOGO_ALPHA))
    text = Image.new("RGBA", block.size, (0, 0, 0, 0))
    ImageDraw.Draw(text).text(((lw - tw) // 2 - tb[0], logo.height + gap - tb[1]), SITE, font=font,
                              fill=TEXT_RGB + (int(255 * TEXT_ALPHA),))
    block.alpha_composite(text)
    block = block.rotate(math.degrees(math.atan2(H, W)), expand=True, resample=Image.BICUBIC)
    page = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    x, y = (W - block.width) // 2, (H - block.height) // 2
    page.alpha_composite(block.crop((max(0, -x), max(0, -y), max(0, -x) + min(W, block.width),
                                     max(0, -y) + min(H, block.height))), (max(0, x), max(0, y)))
    buf = io.BytesIO()
    page.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def _lock_opts():
    perms = (pymupdf.PDF_PERM_PRINT | pymupdf.PDF_PERM_PRINT_HQ | pymupdf.PDF_PERM_COPY
             | pymupdf.PDF_PERM_ACCESSIBILITY)
    return dict(garbage=3, deflate=True, encryption=pymupdf.PDF_ENCRYPT_AES_256,
                owner_pw=secrets.token_urlsafe(24), user_pw="", permissions=perms)


@lru_cache(maxsize=1)
def _text_font():
    return pymupdf.Font(fontfile=FONT) if FONT and FONT.endswith(".ttf") else pymupdf.Font("helv")


def _flatten(src):
    """New PDF whose pages are images (content + mark) with the original words as invisible, selectable text."""
    out = pymupdf.open()
    for page in src:
        r = page.rect
        page.insert_image(r, stream=overlay(round(r.width), round(r.height)), overlay=True, keep_proportion=False)
        pix = page.get_pixmap(dpi=FLAT_DPI)
        img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=82, optimize=True)
        new = out.new_page(width=r.width, height=r.height)
        new.insert_image(r, stream=buf.getvalue())
        tw = pymupdf.TextWriter(r)
        font = _text_font()
        for x0, y0, x1, y1, word, *_ in page.get_text("words"):
            fs = max(4.0, (y1 - y0) * 0.78)
            try:
                tw.append((x0, y1 - (y1 - y0) * 0.22), word, font=font, fontsize=fs)
            except Exception:
                pass
        tw.write_text(new, render_mode=3)          # 3 = invisible: copy/search work, nothing to edit visually
    out.subset_fonts()
    out.set_metadata({"title": src.metadata.get("title") or "", "author": "Gennoor Tech",
                      "subject": SITE, "producer": "Gennoor Tech", "creator": "Gennoor Tech"})
    return out


def stamp_bytes(data, mode="flatten"):
    doc = pymupdf.open(stream=data, filetype="pdf")
    if mode == "flatten":
        doc = _flatten(doc)
    else:
        for page in doc:
            r = page.rect
            page.insert_image(r, stream=overlay(round(r.width), round(r.height)), overlay=True,
                              keep_proportion=False)
    return doc.tobytes(**_lock_opts())


# ---------------- Word ----------------

def _anchor_xml(rid, cx, cy, pid):
    return (
        '<wp:anchor xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="0" behindDoc="1" locked="1" '
        'layoutInCell="1" allowOverlap="1"><wp:simplePos x="0" y="0"/>'
        '<wp:positionH relativeFrom="page"><wp:align>center</wp:align></wp:positionH>'
        '<wp:positionV relativeFrom="page"><wp:align>center</wp:align></wp:positionV>'
        f'<wp:extent cx="{cx}" cy="{cy}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapNone/>'
        f'<wp:docPr id="{pid}" name="Gennoor watermark {pid}" descr="{SITE}"/>'
        '<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1" noSelect="1" noMove="1" noResize="1"/>'
        '</wp:cNvGraphicFramePr><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        f'<pic:pic><pic:nvPicPr><pic:cNvPr id="{pid}" name="gennoor-watermark.png"/><pic:cNvPicPr>'
        '<a:picLocks noChangeAspect="1" noSelect="1" noMove="1" noResize="1"/></pic:cNvPicPr></pic:nvPicPr>'
        f'<pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:anchor>')


def _add_mark(doc):
    from docx.oxml import parse_xml
    from docx.oxml.ns import qn
    pid = 9000
    for sec in doc.sections:
        w_pt, h_pt = sec.page_width.pt, sec.page_height.pt
        png = io.BytesIO(overlay(round(w_pt), round(h_pt)))
        for hdr in {id(h): h for h in [sec.header, sec.first_page_header, sec.even_page_header]}.values():
            hdr.is_linked_to_previous = False
            p = hdr.paragraphs[0] if hdr.paragraphs else hdr.add_paragraph()
            run = p.add_run()
            png.seek(0)
            run.add_picture(png)                                  # inline first: creates the image relationship
            inline = run._r.find(qn("w:drawing")).find(qn("wp:inline"))
            rid = inline.find(".//" + qn("a:blip")).get(qn("r:embed"))
            pid += 1
            inline.getparent().replace(inline, parse_xml(_anchor_xml(rid, int(sec.page_width), int(sec.page_height), pid)))


def _lock_docx(doc):
    """Word 'Restrict editing: read only', enforced with a random password nobody keeps."""
    import base64, hashlib
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    settings = doc.settings.element
    for old in settings.findall(qn("w:documentProtection")):
        settings.remove(old)
    salt = secrets.token_bytes(16)
    h = hashlib.sha512(salt + secrets.token_urlsafe(24).encode("utf-16-le")).digest()
    for i in range(100000):
        h = hashlib.sha512(h + i.to_bytes(4, "little")).digest()
    dp = OxmlElement("w:documentProtection")
    for k, v in [("w:edit", "readOnly"), ("w:enforcement", "1"), ("w:cryptProviderType", "rsaAES"),
                 ("w:cryptAlgorithmClass", "hash"), ("w:cryptAlgorithmType", "typeAny"),
                 ("w:cryptAlgorithmSid", "14"), ("w:cryptSpinCount", "100000"),
                 ("w:hash", base64.b64encode(h).decode()), ("w:salt", base64.b64encode(salt).decode())]:
        dp.set(qn(k), v)
    settings.insert(0, dp)


def stamp_docx(src, dst, lock=True):
    import docx
    doc = docx.Document(str(src))
    _add_mark(doc)
    if lock:
        _lock_docx(doc)
    doc.core_properties.comments = SITE
    doc.save(str(dst))


def docx_to_pdf(docx_path, pdf_path):
    import win32com.client
    word = win32com.client.DispatchEx("Word.Application")
    word.Visible = False
    word.DisplayAlerts = 0
    try:
        d = word.Documents.Open(str(Path(docx_path).resolve()), ReadOnly=True, AddToRecentFiles=False)
        d.ExportAsFixedFormat(str(Path(pdf_path).resolve()), 17)
        d.Close(False)
    finally:
        word.Quit()


def blank(dst):
    import docx
    from docx.shared import Mm
    doc = docx.Document()
    doc.sections[0].page_width, doc.sections[0].page_height = Mm(210), Mm(297)     # A4
    _add_mark(doc)
    doc.core_properties.author = "Gennoor Tech"
    doc.core_properties.comments = SITE
    doc.save(str(dst))


def process(path):
    path = Path(path)
    out = path.with_name(f"{path.stem} - Gennoor{path.suffix}")
    if path.suffix.lower() == ".pdf":
        out.write_bytes(stamp_bytes(path.read_bytes()))
        return [out]
    if path.suffix.lower() == ".docx":
        stamp_docx(path, out)
        pdf = out.with_suffix(".pdf")
        tmp = path.with_name(f"~{path.stem}.tmp.pdf")
        docx_to_pdf(path, tmp)                       # Word renders the original; the mark is added on flatten
        pdf.write_bytes(stamp_bytes(tmp.read_bytes()))
        tmp.unlink()
        return [out, pdf]
    raise SystemExit(f"not a PDF or Word file: {path}")


if __name__ == "__main__":
    if sys.argv[1:2] == ["--blank"]:
        blank(sys.argv[2]); print("wrote", sys.argv[2]); sys.exit()
    for a in sys.argv[1:]:
        for o in process(a):
            print("wrote", o)
