"""make_student_pack.py - ONE student folder for the whole course (owner, 2026-10-07), no zips inside:

    AI-103 - Student files/
      README.md                                  how the folder is organised
      AI-103 - Before you start.pdf / .docx
      Module 0 - Introduction/PPT/               the intro deck as a PDF
      Module N - <name>/
        Lab/      lab code + data only (no guides)
        PPT/      every deck of the module as a PDF
        Guides/   lab guide, demo guide, knowledge check, setup guides (PDF + DOCX)

Every PDF is FLATTENED with the Gennoor watermark baked into the page image (watermark.py): converting it back to
PowerPoint or Word gives pictures with the mark in them. PDFs are also locked against editing. DOCX files carry the
watermark behind the text in every header and are locked read-only (a Word file can never be fully tamper-proof:
the flattened PDF next to it is the protected copy). Data PDFs used by the labs keep real text (overlay mark).

    python make_student_pack.py              -> AI-103 Labs/Shipped/AI-103 - Student files/
"""
from course import CFG, CODE, SHORT, ROOT, REC, LABS, VIDEO, UDEMY, UDEMY_QUIZ, UDEMY_RES, UDEMY_PKG, PILOT, COURSE_DIR, LECTURES, VOICE  # noqa: E402,F401
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import ship_module as S                                  # scan (leaks), brand (watermark), docx_to_pdf, skip lists

LABS = LABS
DECKS = COURSE_DIR
OUT = LABS / "Shipped" / f"{CODE} - Student files"
LABDIR = {m['n']: m['lab_dir'] for m in CFG['modules']}
GUIDE_HINTS = ("Lab guide", "Demo guide", "Knowledge check", "Setup guide")


def pptx_to_pdf(pptx: Path, pdf: Path):
    if pdf.exists() and pdf.stat().st_mtime >= pptx.stat().st_mtime:
        return
    import win32com.client
    app = win32com.client.DispatchEx("PowerPoint.Application")
    try:
        pres = app.Presentations.Open(str(pptx), True, False, False)   # read-only, no window
        pres.SaveAs(str(pdf), 32)                                        # ppSaveAsPDF
        pres.Close()
    finally:
        app.Quit()


def write(dst: Path, data: bytes):
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(data)


def lab_files(src: Path):
    """Lab code and data only: no guides, no Word/PowerPoint sources at the top, no caches or secrets."""
    for p in sorted(src.rglob("*")):
        rel = p.relative_to(src)
        if not p.is_file() or rel.parts[0].endswith("Content I did") or rel.parts[0].startswith("_"):
            continue
        if S.SKIP_DIRS & set(rel.parts[:-1]) or p.name in S.SKIP_FILES or p.suffix.lower() in S.SKIP_EXT:
            continue
        if any(h in p.name for h in GUIDE_HINTS) or p.name.startswith(f"{CODE} - "):
            continue
        if len(rel.parts) == 1 and p.suffix.lower() in S.ROOT_SOURCES:
            continue
        yield rel, p


def guide_files(src: Path):
    for p in sorted(src.rglob("*")):
        if p.is_file() and p.suffix.lower() in (".pdf", ".docx") and any(h in p.name for h in GUIDE_HINTS) \
                and "_originals" not in p.parts and "Content I did" not in str(p):
            yield p


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    tmp = LABS / "_recording" / "pack_tmp"
    tmp.mkdir(exist_ok=True)
    leaks, count = [], 0

    def add(dst: Path, name: str, data: bytes, data_file=False):
        nonlocal count
        hit = S.scan(name, data)
        if hit:
            leaks.append(f"{dst.relative_to(OUT)}: {hit}")
        low = name.lower()
        if low.endswith(".pdf"):
            data = S.brand("data/" + name if data_file else name, data)     # data PDFs: overlay, others: flatten
        elif low.endswith(".docx"):
            data = S.brand(name, data)
        write(dst, data); count += 1

    for q in sorted(LABS.glob(f"{CODE} - *")):
        if q.is_file() and q.suffix.lower() in (".pdf", ".docx"):
            add(OUT / q.name, q.name, q.read_bytes())

    for deck_dir in sorted(DECKS.iterdir()):
        if not deck_dir.is_dir():
            continue
        for pptx in sorted(deck_dir.rglob("*.pptx")):
            pdf = tmp / (pptx.stem + ".pdf")
            pptx_to_pdf(pptx, pdf)
            add(OUT / deck_dir.name / "PPT" / pdf.name, pdf.name, pdf.read_bytes())
            print("deck", pptx.stem, flush=True)

    import re as _re
    names = {int(_re.match(r"Module (\d+)", d.name).group(1)): d.name for d in DECKS.iterdir() if d.is_dir() and _re.match(r"Module \d+", d.name)}
    for n, lab_dir in LABDIR.items():
        name = names[n]
        src = LABS / lab_dir
        mod = OUT / name
        for rel, p in lab_files(src):
            add(mod / "Lab" / rel, rel.as_posix(), p.read_bytes(), data_file="data" in rel.parts)
        for p in guide_files(src):
            if p.suffix.lower() == ".docx":
                S.docx_to_pdf(p, p.with_suffix(".pdf"))
            add(mod / "Guides" / p.name, p.name, p.read_bytes())
        print("module", n, "done", flush=True)

    if leaks:
        print("NOT SHIPPED - personal values found:\n  " + "\n  ".join(leaks))
        shutil.rmtree(OUT)
        sys.exit(2)
    readme = [f"# {CODE} - Student files", "",
              "One folder per module:", "",
              "- **Lab/** - the lab code and data. Open this folder in VS Code and follow the lab guide.",
              "- **PPT/** - the slides of every section, as PDF.",
              "- **Guides/** - the lab guide, the demo guide and the knowledge check (PDF and Word); "
              "", "",
              f"Start with **{CODE} - Before you start.pdf**, then Module 1.", "",
              "Never share your own `.env` file: it holds your endpoint and settings.", ""]
    write(OUT / "README.md", "\n".join(readme).encode("utf-8"))
    size = sum(p.stat().st_size for p in OUT.rglob("*") if p.is_file())
    print(f"\nwrote {OUT} - {count + 1} files, {size // (1024 * 1024)} MB")


if __name__ == "__main__":
    main()
