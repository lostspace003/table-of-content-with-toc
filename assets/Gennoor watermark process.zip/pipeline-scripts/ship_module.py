"""Build the student zip for one module: clean code, data, lab guide, knowledge check and setup guides.

Usage: python ship_module.py <module number>
Output: AI-103 Labs/Shipped/AI-103 - Module <N> - Student files.zip
Every PDF and Word file gets the Gennoor watermark and a lock (watermark.py): guide PDFs are flattened (no software
can edit them); data PDFs keep real text (the lab indexes them) and data .docx files are locked read-only.
Never shipped: "Module <N> Content I did", .env, .venv, caches, Word sources, recordings.
"""
import sys as _s; from pathlib import Path as _P; _s.path.insert(0, str(_P(__file__).resolve().parent))  # noqa: E702
from course import CFG, module_cfg, CODE, SHORT, ROOT, REC, LABS, VIDEO, UDEMY, UDEMY_QUIZ, UDEMY_RES, UDEMY_PKG, PILOT, COURSE_DIR, LECTURES, VOICE  # noqa: E402,F401
import re
import sys
import zipfile
from pathlib import Path

LABS = LABS
SHIP = LABS / "Shipped"
SKIP_DIRS = {".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache", "node_modules", ".vscode", ".idea",
             ".claude"}                          # Claude Code session files (module-1 is its working folder)
SKIP_FILES = {".env", ".DS_Store", "Thumbs.db"}
SKIP_EXT = {".pyc", ".mp4", ".mkv", ".log", ".tmp", ".lock", ".svg"}   # .svg: the watermark logo, not lab content
ROOT_SOURCES = {".docx", ".pptx"}  # Word/PowerPoint sources of the guides; data/ keeps its .docx
# Personal or live values that must never reach students
LEAKS = [r"admin-0564", r"gennoor", r"\blosts\b", r"lostspace", r"2f55ca6d", r"roohi", r"8bc31a35", r"b128d35a", r"vs_[A-Za-z0-9]{20}",
         r"InstrumentationKey=(?!\.\.\.|<)",r"(?i)api[_-]?key\s*=\s*(?!get_bearer_token_provider|os\.environ)\S{16,}", r"sk-[A-Za-z0-9]{20}"]
TEXT_EXT = {".py", ".md", ".txt", ".json", ".example", ".toml", ".yml", ".yaml", ".env", ".ps1", ".sh", ".csv", ".bicep", ".cfg", ".ini"}


def docx_to_pdf(docx, pdf):
    if pdf.exists() and pdf.stat().st_mtime >= docx.stat().st_mtime:
        return
    import win32com.client
    word = win32com.client.DispatchEx("Word.Application")
    word.Visible = False
    try:
        d = word.Documents.Open(str(docx), ReadOnly=True)
        d.ExportAsFixedFormat(str(pdf), 17)
        d.Close(False)
    finally:
        word.Quit()


def parts_line(n):
    for line in (LABS / "README.md").read_text(encoding="utf-8").splitlines():
        if line.startswith(f"- Module {n}:") or (n in "34" and line.startswith("- Modules 3 and 4:")):
            return line[2:]
    return ""


def readme(n, mod, guides):
    title = (mod / f"Module {n} - Lab guide.pdf").exists() and f"Module {n} - Lab guide.pdf"
    secs = sorted([p.name for p in mod.iterdir() if p.is_dir() and p.name.startswith("section-")],
                  key=lambda s: int(s.split("-")[1]))
    lines = [f"# {CODE} - Module {n} - Student files", "",
             "## What is inside", ""]
    for g in guides:
        lines.append(f"- **{g}**")
    lines += [f"- `{s}/` - the code for that lab part" for s in secs]
    for extra in ["common", "capstone"]:
        if (mod / extra).is_dir():
            lines.append(f"- `{extra}/` - shared code used by several parts")
    if (mod / "data").is_dir():
        lines.append(f"- `data/` - {CFG.get('story', {}).get('company', 'the course')}'s sample data")
    lines += ["- `requirements.txt`, `.env.example` - packages and settings", "",
              "## Start here", "",
              "1. Follow the setup guides once (Azure subscription, Python 3.13, VS Code)." if n == "1"
              else "1. Finish the setup from Module 1 (Azure subscription, Python 3.13, VS Code, `az login`).",
              f"2. Open this folder in VS Code and create a virtual environment: `py -3.13 -m venv .venv` "
              "(macOS/Linux: `python3.13 -m venv .venv`), then select it as the interpreter.",
              "3. Install the packages: `pip install -r requirements.txt`",
              "4. Copy `.env.example` to `.env` and fill in your Foundry project endpoint.",
              "5. Sign in once: `az login`. All code is keyless (`DefaultAzureCredential`).",
              f"6. Follow **{title or 'the lab guide'}** part by part, with the lab videos.", ""]
    pl = parts_line(n)
    if pl:
        lines += ["## Lab parts and folders", "", pl, ""]
    lines += ["Never share your `.env` file: it holds your own endpoint and settings.", ""]
    return "\n".join(lines)


def scan(name, data):
    if Path(name).suffix.lower() not in TEXT_EXT and not name.endswith(".example"):
        return []
    text = data.decode("utf-8", errors="ignore")
    return [p for p in LEAKS if re.search(p, text)]


def brand(name, data):
    from watermark import stamp_bytes, stamp_docx
    low = name.lower()
    if low.endswith(".pdf"):
        return stamp_bytes(data, mode="flatten" if "/" not in name or name.endswith("Lab guide.pdf") else "overlay")
    if low.endswith(".docx"):
        import tempfile
        with tempfile.TemporaryDirectory() as t:
            src, dst = Path(t) / "in.docx", Path(t) / "out.docx"
            src.write_bytes(data)
            stamp_docx(src, dst)
            return dst.read_bytes()
    return data


def main(n):
    lab_dir = module_cfg(n).get("lab_dir", f"module-{n}")       # AI-500: module-01
    mod = LABS / lab_dir
    SHIP.mkdir(exist_ok=True)
    out = SHIP / f"{CODE} - Module {n} - Student files.zip"
    root = f"labs/{lab_dir}"   # the lab guides say: cd labs/<lab folder>
    for kc in mod.glob(f"Module {n} - Knowledge check.docx"):
        docx_to_pdf(kc, kc.with_suffix(".pdf"))
    for lg in mod.glob(f"Module {n} - Lab guide.docx"):
        docx_to_pdf(lg, lg.with_suffix(".pdf"))
    files, leaks = [], []
    for p in sorted(mod.rglob("*")):
        rel = p.relative_to(mod)
        if not p.is_file() or rel.parts[0].endswith("Content I did") or rel.parts[0].startswith("_"):
            continue
        if SKIP_DIRS & set(rel.parts[:-1]) or p.name in SKIP_FILES or p.suffix.lower() in SKIP_EXT \
                or (len(rel.parts) == 1 and p.suffix.lower() in ROOT_SOURCES)                 or p.name.endswith("Lab guide.docx"):           # Module 5 keeps its guide inside capstone new/
            continue
        data = p.read_bytes()
        hit = scan(p.name, data)
        if hit:
            leaks.append(f"{rel}: {hit}")
        files.append((rel.as_posix(), data))
    start = LABS / f"{CODE} - Before you start.pdf"
    if start.exists():
        files.append((start.name, start.read_bytes()))
    if leaks:
        print("NOT SHIPPED - personal values found:\n  " + "\n  ".join(leaks))
        sys.exit(2)
    guides = sorted({f for f, _ in files if f.endswith(".pdf") and ("/" not in f or f.endswith("Lab guide.pdf"))})
    files.append(("README.md", readme(n, mod, guides).encode("utf-8")))
    files = [(f, brand(f, d)) for f, d in files]
    course = (LABS / "README.md").read_bytes()
    if scan("README.md", course):
        print("NOT SHIPPED - personal values in the course README"); sys.exit(2)
    tmp = out.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files:
            z.writestr(f"{root}/{name}", data)
        z.writestr("labs/README.md", course)
    tmp.replace(out)
    print(f"shipped {out} - {len(files)} files, {out.stat().st_size // 1024} KB")
    for name, _ in files:
        print("  ", name)


if __name__ == "__main__":
    main(sys.argv[1])
