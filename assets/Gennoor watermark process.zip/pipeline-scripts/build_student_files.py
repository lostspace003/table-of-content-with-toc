"""FABRIC student files (course-specific; run from the factory venv):

    recording\\tools\\.venv\\Scripts\\python.exe courses\\FABRIC\\tools\\build_student_files.py

Writes  FABRIC Labs\\Shipped\\FABRIC - Student files\\   (the layout make_studio_package.py reads)
        FABRIC Labs\\Shipped\\FABRIC - Module 2 - Student files.zip, ... Module 3 ...
Every PDF is flattened with the Gennoor watermark (watermark\\gennoor_watermark.py) and locked; links are kept.
HTML is only the intermediate step (headless Chrome prints it to PDF) and is never shipped.
Producer notes (verify markers, kit references, dry-run notes) are removed from everything students receive (scrub.py).
"""
from __future__ import annotations
import html
import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent                                   # courses\FABRIC
FC = ROOT / "fabric-course"
LABS = ROOT / "FABRIC Labs"
SHIP = LABS / "Shipped"
PACK = SHIP / "FABRIC - Student files"
TMP = LABS / "_recording" / "pack_tmp"
FACTORY = ROOT.parents[1]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(FACTORY / "watermark"))
from scrub import scrub, residue                     # noqa: E402
import gennoor_watermark as GW                       # noqa: E402
import pymupdf                                       # noqa: E402
from markdown_it import MarkdownIt                   # noqa: E402

CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
CFG = json.loads((ROOT / "COURSE.json").read_text(encoding="utf-8"))
MODS = {m["n"]: m for m in CFG["modules"]}


def clean_name(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r'[<>:"/\\|?*]', "", s)).strip()


MODDIR = {n: f"Module {n} - {clean_name(m['title'])}" for n, m in MODS.items()}

CSS = """
@page { size: A4; margin: 16mm 15mm 20mm 15mm; }
* { box-sizing: border-box; }
body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 10.3pt; line-height: 1.5; color: #1d2733; }
h1 { font-size: 22pt; margin: 0 0 3mm; color: #0b2a4a; line-height: 1.2; }
h2 { font-size: 14pt; margin: 8mm 0 2.5mm; color: #0b2a4a; border-bottom: 1.5px solid #0f7b6c; padding-bottom: 1mm; page-break-after: avoid; }
h3 { font-size: 11.5pt; margin: 5mm 0 1.5mm; color: #0f7b6c; page-break-after: avoid; }
p { margin: 0 0 2.6mm; }
ul, ol { margin: 0 0 3mm; padding-left: 6.5mm; }
li { margin-bottom: 1.2mm; }
code { font-family: Consolas, 'Cascadia Mono', monospace; font-size: 9.2pt; background: #eef1f4; padding: 0.2mm 1mm; border-radius: 1mm; color: #0a3d62; }
pre { background: #f4f6f8; border-left: 3px solid #0f7b6c; padding: 3mm 4mm; margin: 0 0 3.5mm; overflow: hidden; white-space: pre-wrap; word-break: break-word; page-break-inside: avoid; }
pre code { background: none; padding: 0; font-size: 8.8pt; color: #1d2733; }
table { border-collapse: collapse; width: 100%; margin: 1mm 0 4mm; font-size: 9.2pt; page-break-inside: avoid; }
th { background: #0b2a4a; color: #fff; text-align: left; padding: 1.5mm 2.2mm; font-weight: 600; }
td { border-bottom: 1px solid #d5dbe1; padding: 1.4mm 2.2mm; vertical-align: top; }
tr:nth-child(even) td { background: #f7f9fa; }
blockquote { margin: 0 0 3.5mm; padding: 2.5mm 4mm; background: #eef6f4; border-left: 3px solid #0f7b6c; border-radius: 0 1.5mm 1.5mm 0; page-break-inside: avoid; }
blockquote p:last-child { margin-bottom: 0; }
blockquote.oneminute { background: #eef2fb; border-left-color: #3b5bdb; }
p.cp { background: #e7f5ec; border: 1px solid #9fd3b1; border-radius: 1.5mm; padding: 2.3mm 3.5mm; page-break-inside: avoid; }
hr { display: none; }
a { color: #0b5cad; text-decoration: none; }
.kicker { font-size: 8.5pt; letter-spacing: 0.08em; text-transform: uppercase; color: #0f7b6c; font-weight: 600; margin-bottom: 1.5mm; }
.badge { display: inline-block; background: #fff4d6; border: 1px solid #e8c766; color: #6b4e00; font-size: 8.5pt; padding: 0.6mm 2.2mm; border-radius: 2mm; margin-left: 2mm; vertical-align: middle; }
.meta { background: #f4f6f8; border-radius: 2mm; padding: 3mm 4mm; margin: 3mm 0 5mm; font-size: 9.6pt; }
.meta b { color: #0b2a4a; }
.meta ul { margin: 1mm 0 0; }
.small { font-size: 8.8pt; color: #4a5568; }
.pagebreak { page-break-before: always; }
"""


def chrome_pdf(html_text: str, out: Path, landscape: bool = False, name: str = "page"):
    TMP.mkdir(parents=True, exist_ok=True)
    f = TMP / f"{name}.html"
    css = CSS + ("@page { size: A4 landscape; margin: 11mm 12mm 14mm 12mm; }" if landscape else "")
    f.write_text(f"<!doctype html><html lang='en'><head><meta charset='utf-8'><style>{css}</style></head><body>{html_text}</body></html>", encoding="utf-8")
    prof = TMP / "chrome_profile"
    cmd = [CHROME, "--headless=new", "--disable-gpu", "--no-sandbox", "--no-pdf-header-footer", f"--user-data-dir={prof}",
           f"--print-to-pdf={out}", f.as_uri()]
    subprocess.run(cmd, check=True, capture_output=True, timeout=180)
    if not out.exists() or out.stat().st_size < 2000:
        raise SystemExit(f"Chrome did not write {out}")


def finalize(pdf: bytes, footer: str, number_pages: bool = True) -> bytes:
    """footer text + page number, then flatten with the Gennoor mark (links kept) and lock"""
    src = pymupdf.open(stream=pdf, filetype="pdf")
    links = [p.get_links() for p in src]
    n = len(src)
    if number_pages:
        for i, page in enumerate(src, 1):
            r = page.rect
            page.insert_text((r.x0 + 40, r.y1 - 22), footer, fontname="helv", fontsize=7.5, color=(0.45, 0.5, 0.56))
            t = f"{i} / {n}"
            page.insert_text((r.x1 - 40 - pymupdf.get_text_length(t, "helv", 7.5), r.y1 - 22), t, fontname="helv", fontsize=7.5, color=(0.45, 0.5, 0.56))
    flat = GW._flatten(src)
    for page, ls in zip(flat, links):
        for l in ls:
            if l.get("uri"):
                page.insert_link({"kind": pymupdf.LINK_URI, "from": l["from"], "uri": l["uri"]})
    return flat.tobytes(**GW._lock_opts())


def write_pdf(html_text: str, dest: Path, footer: str, landscape: bool = False, name: str = "page"):
    raw = TMP / f"{name}.pdf"
    chrome_pdf(html_text, raw, landscape, name)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(finalize(raw.read_bytes(), footer))
    print("  pdf", dest.name, f"{dest.stat().st_size // 1024} KB")


MD = MarkdownIt("commonmark").enable("table")


def md_to_html(text: str) -> str:
    out = MD.render(text)
    out = re.sub(r"<p>(✅)", r'<p class="cp">\1', out)
    out = re.sub(r"<blockquote>\n<p>(📘)", r'<blockquote class="oneminute">\n<p>\1', out)
    return out


# ------------------------------------------------------------------ lab guides
GUIDES = {   # source folder -> (pdf name, kicker)
    "part-3-project/lab-01-land-the-data": "Lab 1 - Land the data - Lab guide.pdf",
    "part-3-project/lab-02-features": "Lab 2 - Bronze to silver to gold features - Lab guide.pdf",
    "part-3-project/lab-03-train": "Lab 3 - Train, track, register - Lab guide.pdf",
    "part-3-project/lab-04-endpoint-app": "Lab 4 - Real-time endpoint and checkout app - Lab guide.pdf",
    "part-3-project/lab-05-stream-dashboard-alert": "Lab 5 - Stream, live dashboard, alert - Lab guide.pdf",
    "part-3-project/lab-06-batch-powerbi": "Lab 6 - Batch scoring, orchestration, Power BI - Lab guide.pdf",
    "part-3-project/lab-07-operate": "Lab 7 - Operate: versions, lineage, cost - Lab guide.pdf".replace(":", ""),
    "optional/3.8-ai-layer-paid": "Optional 3.8 - AI layer on paid capacity - Lab guide.pdf",
    "optional/3.9-azure-ml-alternative": "Optional 3.9 - Azure ML managed online endpoint - Lab guide.pdf",
}


def front_matter(text: str):
    m = re.match(r"---\n(.*?)\n---\n", text, re.S)
    meta, body = {}, text
    if m:
        body = text[m.end():]
        cur = None
        for line in m.group(1).splitlines():
            if re.match(r"^\s+- ", line) and cur:
                meta.setdefault(cur, []).append(line.strip()[2:].strip().strip('"'))
            elif ":" in line:
                k, v = line.split(":", 1)
                cur = k.strip()
                v = v.strip().strip('"')
                meta[cur] = v if v else []
    return meta, body


def lab_guide_html(src: Path):
    raw = (src / "lab-guide.md").read_text(encoding="utf-8")
    meta, body = front_matter(raw)
    body = scrub(body)
    # footnotes [^1]: ... -> a Sources list
    notes = dict((k, v.strip()) for k, v in re.findall(r"(?m)^\[\^(\d+)\]:\s*(.*)$", body))
    body = re.sub(r"(?m)^\[\^\d+\]:.*\n?", "", body)
    body = re.sub(r"\[\^(\d+)\]", lambda m: f"<sup>{m.group(1)}</sup>", body)
    body = re.sub(r"(?m)^# .*\n", "", body, count=1)                # the title comes from the front matter
    title = scrub(meta.get("title", src.name))
    num = meta.get("id", "")
    kicker = "FABRIC · Build Real-Time AI on Microsoft Fabric"
    badge = f'<span class="badge">{html.escape(scrub(meta["label"]))}</span>' if meta.get("label") else ""
    you = meta.get("you_need", [])
    if isinstance(you, str):
        you = [you]
    needs = "".join(f"<li>{html.escape(scrub(x))}</li>" for x in you)
    t = scrub(meta.get("time", ""))
    head = (f'<div class="kicker">{html.escape(kicker)}</div><h1>{html.escape(title)}{badge}</h1>'
            f'<div class="meta"><b>Video length:</b> {html.escape(t)} (allow more time when you follow the steps yourself)<br>'
            f'<b>Builds on:</b> {html.escape(scrub(meta.get("builds_on", "")))}'
            f'{"<br><b>You need:</b><ul>" + needs + "</ul>" if needs else ""}</div>')
    html_body = md_to_html(body)
    if notes:
        html_body += "<h2>Sources</h2><ol>" + "".join(f"<li>{html.escape(v)}</li>" for _k, v in sorted(notes.items())) + "</ol>"
        html_body = re.sub(r"(https?://[^\s<]+)", r'<a href="\1">\1</a>', html_body) if False else html_body
    return head + html_body, title, residue(body)


# ------------------------------------------------------------------ ML cards
def ml_cards_html():
    text = (FC / "course" / "ML_CARDS.md").read_text(encoding="utf-8")
    parts = [p for p in re.split(r"\n---\n", text) if "<a id=" in p]
    cards = []
    for p in parts:
        title = re.search(r"(?m)^## (.+)$", p).group(1).strip()
        slug = re.search(r'<a id="([^"]+)"', p).group(1)
        body = p.split(f'<a id="{slug}"></a>', 1)[1]
        main = body.split("**Reference:**")[0].strip()
        ref = re.search(r"\*\*Reference:\*\*\s*(.+)", body).group(1).strip()
        cards.append((title, slug, scrub(main), scrub(ref)))
    out = ['<div class="kicker">FABRIC · Build Real-Time AI on Microsoft Fabric</div><h1>In one minute: the machine-learning ideas behind the project</h1>'
           '<p>The course does not teach machine learning; it uses it. Each card gives one idea in two or three plain sentences, a picture, '
           'and one authentic reference to read next. The labs point to a card the first time its idea appears.</p><h2>The cards</h2><ol>']
    out += [f"<li>{html.escape(t)}</li>" for t, *_ in cards]
    out.append("</ol>")
    for i, (t, slug, main, ref) in enumerate(cards, 1):
        img = (FC / "slides" / "out" / "ml-cards" / f"{slug}.png")
        if not img.exists():
            raise SystemExit(f"missing card image {img}")
        ref_html = re.sub(r"(https?://[^\s<>]+)", r'<a href="\1">\1</a>', html.escape(ref))
        out.append(f'<div class="pagebreak"></div><div class="kicker">Card {i} of {len(cards)} · In one minute</div><h2 style="margin-top:0">{html.escape(t)}</h2>'
                   f'<img src="{img.as_uri()}" style="width:176mm;display:block;margin:0 auto 4mm;border:1px solid #d5dbe1">'
                   f'{md_to_html(main)}<p class="small"><b>Reference:</b> {ref_html}</p>')
    return "".join(out)


# ------------------------------------------------------------------ cheat sheet
def cheat_sheet_html():
    c = json.loads((FC / "kit" / "contracts" / "feature_contract.json").read_text(encoding="utf-8"))
    rows = "".join(f"<tr><td>{i['order']}</td><td><code>{i['name']}</code></td><td>{i['type']}</td>"
                   f"<td>{i.get('min', '')}{'–' + str(i['max']) if 'max' in i else ''}</td><td>{html.escape(i.get('description', ''))}</td></tr>"
                   for i in c["inputs"])
    lessons = [
        ("Module 1 · Tour of Fabric (25 min)", [("1.1", "What is Fabric", 4), ("1.2", "Get access: licenses, account, trial", 8), ("1.3", "Platform tour", 13)]),
        ("Module 2 · How Fabric Is Useful (44 min)", [("2.0", "Meet Brightcart", 1), ("2.1", "OneLake and lakehouse", 5), ("2.2", "Data Factory: Dataflow Gen2, pipeline, Copy job", 6),
                                                      ("2.3", "Data Engineering: notebooks and Spark", 4), ("2.4", "Data Warehouse", 4), ("2.5", "SQL database and mirroring", 3),
                                                      ("2.6", "Real-Time Intelligence", 5), ("2.7", "Activator", 3), ("2.8", "Data Science: experiments and models", 4),
                                                      ("2.9", "Power BI: semantic model, Direct Lake, report", 4), ("2.10", "Fabric IQ, Copilot and data agent (paid capacity)", 2),
                                                      ("2.11", "Platform glue: catalog, lineage, Git, deployment pipelines", 3)]),
        ("Module 3 · Project: Brightcart Delivery Promise (78 min)", [("3.0", "Project brief and architecture", 3), ("3.1", "Lab 1 · Land the data", 10), ("3.2", "Lab 2 · Bronze → silver → gold features", 12),
                                                                     ("3.3", "Lab 3 · Train, track, register", 13), ("3.4", "Lab 4 · Real-time endpoint and checkout app", 10),
                                                                     ("3.5", "Lab 5 · Stream, live dashboard, alert", 10), ("3.6", "Lab 6 · Batch scoring, orchestration, Power BI", 10),
                                                                     ("3.7", "Lab 7 · Operate: versions, lineage, cost", 5), ("W", "Wrap-up and next steps", 5),
                                                                     ("3.8", "Optional · AI layer on paid capacity (optional, outside the main run)", 8), ("3.9", "Optional · Azure ML managed online endpoint (optional, outside the main run)", 10)]),
    ]
    mp = "".join(f"<h3>{html.escape(t)}</h3><table><tr><th style='width:12mm'>ID</th><th>Lesson</th><th style='width:20mm'>Planned min</th></tr>" +
                 "".join(f"<tr><td>{a}</td><td>{html.escape(b)}</td><td>{m}</td></tr>" for a, b, m in ls) + "</table>" for t, ls in lessons)
    items = [
        ("Part 2 demos", "ws-fabric-tour", "workspace for every demo (license mode: Trial)"),
        ("2.1", "lh_reference", "lakehouse: ref_carriers, ref_warehouses, ref_regions, sample_orders (and ref_calendar from 2.2)"),
        ("2.2", "df_calendar · pl_tour_copy", "Dataflow Gen2 that builds ref_calendar · pipeline with one Copy data activity"),
        ("2.3 · 2.4", "nb_tour · wh_tour", "demo notebook · demo warehouse"),
        ("2.5", "sqldb_brightcart_ops", "SQL database: dbo.open_orders (about 1,500 rows) and dbo.risk_alerts; kept for Labs 5 and 6"),
        ("2.6 · 2.7", "es_tour · eh_tour · qs_tour · rtd_tour · act_tour", "demo eventstream, eventhouse, queryset, Real-Time Dashboard, Activator; deleted after 2.7"),
        ("2.8 · 2.9", "nb_ds_tour · exp_tour · mdl_tour · sm_tour · rpt_tour", "demo notebook, experiment, ML model, semantic model, report"),
        ("Lab 1", "ws-brightcart-dp · lh_brightcart · pl_ingest_history", "project workspace · lakehouse with 4 shortcuts to lh_reference · pipeline that lands 5 CSV files in Files/bronze/history"),
        ("Lab 2", "nb_01_bronze_to_silver · nb_02_features", "silver_customers, silver_orders, silver_shipments, silver_daily_ops, silver_weather · gold_training_delivery, gold_fact_orders, gold_dim_carrier, gold_dim_region, gold_dim_warehouse, gold_dim_date"),
        ("Lab 3", "nb_03_train · exp_delivery_promise · mdl_delivery_promise", "runs A_logreg_baseline and B_lightgbm_v1 · version 1 · gold_holdout_scored"),
        ("Lab 4", "sp-brightcart-checkout-app · app/checkout-simulator", "Entra app registration (service principal) · Streamlit app that calls the endpoint"),
        ("Lab 5", "es_checkout_events · eh_brightcart · qs_delivery_promise · rtd_delivery_promise_live · act_delivery_risk_alerts · pl_log_alert", "eventstream · eventhouse with table CheckoutScores · KQL queryset · live dashboard (5 tiles) · Activator rule · fallback pipeline writing dbo.risk_alerts"),
        ("Lab 6", "nb_04_batch_score · pl_nightly_delivery_promise · sm_delivery_promise · rpt_delivery_promise_ops", "batch scoring notebook · nightly pipeline (06:00) · Direct Lake semantic model · report page 1 Today's risk · tables bronze_open_orders, gold_open_orders_features, gold_open_orders_scored"),
        ("Lab 7", "mdl_delivery_promise version 2", "run B_lightgbm_v2 · switch the default version with no app change · clean up"),
    ]
    it = "".join(f"<tr><td>{a}</td><td>{b}</td><td>{html.escape(d)}</td></tr>" for a, b, d in items)
    nums = [
        ("History files", "orders 90,450 rows (90,000 after removing 450 duplicates) · customers 8,000 · shipments 90,000 · daily_ops 2,568 · weather_daily 7,692"),
        ("Reference tables", "carriers 3 · warehouses 4 · regions 12 · calendar 730 days · orders_sample 5,000"),
        ("Features / label", "16 features in a fixed order · label is_late · late rate about 20%"),
        ("Split", "train 77,285 orders before 2026-07-01 · holdout 12,715 orders from 2026-07-01"),
        ("Model score (holdout ROC-AUC)", "baseline about 0.81 · LightGBM v1 about 0.84 · PASS needs 0.80 or more and a gap of 0.03 or more; v2 also lands near 0.84"),
        ("Batch scoring", "1,500 open orders · 74 at-risk (late_risk 0.6 or more) · At-Risk Revenue 9,491.04 · Northway Freight on top"),
        ("Endpoint", "auto sleep after 5 minutes without traffic · first call after idle can be slow or return 202 · about 20 ms per row when warm · activation takes about 5 to 6 minutes on the trial"),
        ("Trial", "60 days · 4 or 64 capacity units · when it ends workspaces fall back to Pro and content stays in OneLake for 7 days"),
    ]
    nt = "".join(f"<tr><td style='width:46mm'><b>{a}</b></td><td>{html.escape(b)}</td></tr>" for a, b in nums)
    return f"""
<div class="kicker">FABRIC · Build Real-Time AI on Microsoft Fabric</div><h1>Course map and cheat sheet</h1>
<p>Everything you need to find your way through the course on two or three pages: the lessons, the names of the items you build, the 16-feature contract, the decision policy, the numbers you should see, common errors and the cost checklist.</p>
<h2>1. The course map</h2>{mp}
<p class="small">Planned minutes come from the course plan; the finished lessons run about 165 minutes in total. Optional lessons sit outside the total.</p>
<h2>2. Items and tables, and where they appear</h2>
<table><tr><th style="width:18mm">Where</th><th style="width:62mm">Name</th><th>What it is</th></tr>{it}</table>
<h2>3. The 16-feature contract</h2>
<p>The same 16 values, in this order, go into training, the model signature, the endpoint call from the app and the batch scoring. The output is one column, <code>late_risk</code> (double, 0 to 1).</p>
<table><tr><th style="width:10mm">#</th><th style="width:38mm">Column</th><th style="width:14mm">Type</th><th style="width:16mm">Range</th><th>Meaning</th></tr>{rows}</table>
<p><b>Never a feature:</b> <code>shipped_ts</code>, <code>delivered_ts</code>, <code>actual_severity</code>, anything recorded after <code>order_ts</code>. The test: is it already written down when the customer clicks Buy?</p>
<h2>4. Decision policy and alert rule</h2>
<table><tr><th>late_risk</th><th>Shipping</th><th>Decision</th></tr>
<tr><td>below 0.35</td><td>any</td><td><code>keep_promise</code></td></tr>
<tr><td>0.35 up to 0.6</td><td>any</td><td><code>extend_promise</code> (one more day)</td></tr>
<tr><td>0.6 or more</td><td>standard</td><td><code>offer_express</code></td></tr>
<tr><td>0.6 or more</td><td>express</td><td><code>extend_promise</code></td></tr></table>
<p><b>Alert rule (Activator):</b> <code>late_risk</code> at or above 0.7 <b>and</b> <code>order_value</code> at or above 200. <b>Batch risk bands:</b> low below 0.35, medium 0.35 to 0.6, high 0.6 or more.</p>
<h2>5. Numbers you should see</h2><table>{nt}</table>
<h2>6. When something fails</h2>
<table><tr><th style="width:36mm">Symptom</th><th>First thing to check</th></tr>
<tr><td>Cannot create an item</td><td>Workspace settings, License info: the license mode must be Trial.</td></tr>
<tr><td>"No default context found"</td><td>Attach <code>lh_brightcart</code> as the default lakehouse of the notebook, then run again.</td></tr>
<tr><td>Copy activity 404</td><td>Paste the URL into a browser. The branch must be <code>main</code> and the base URL must end in <code>/data/history</code>.</td></tr>
<tr><td>Files land with 0 bytes</td><td>Set the file format to Binary on both the source and the destination.</td></tr>
<tr><td>Endpoint call 401</td><td>Token scope <code>https://api.fabric.microsoft.com/.default</code>; check tenant ID, client ID and secret (no trailing space).</td></tr>
<tr><td>Endpoint call 403</td><td>The tenant setting "Service principals can call Fabric public APIs" must be on <b>and</b> the service principal must be Contributor on the workspace.</td></tr>
<tr><td>Endpoint call 404</td><td>Wrong workspace ID or model ID, or the version is not active.</td></tr>
<tr><td>Endpoint call 202 or a time-out</td><td>The endpoint is waking up after auto sleep. Wait and press the button again.</td></tr>
<tr><td>No rows in CheckoutScores</td><td>The connection string in <code>.env</code> is stale (it changes whenever the eventstream is edited), or the destination is not published.</td></tr>
<tr><td>Predictions are only 0 and 1</td><td>A classifier was registered. Re-run <code>nb_03_train</code> so the native LightGBM Booster is registered.</td></tr></table>
<h2>7. Cost checklist: before you walk away</h2>
<table><tr><th style="width:30mm">When</th><th>Do</th></tr>
<tr><td>While working</td><td>Leave endpoint <b>auto sleep on</b>. An active endpoint node draws 5 capacity-unit seconds per second and can scale to three nodes.</td></tr>
<tr><td>End of session</td><td>On <code>mdl_delivery_promise</code>, Manage endpoints: <b>deactivate every version</b>.</td></tr>
<tr><td>End of session</td><td>On <code>pl_nightly_delivery_promise</code>: set the schedule to <b>Off</b>.</td></tr>
<tr><td>End of session</td><td>Stop the Activator rule <code>act_delivery_risk_alerts</code>.</td></tr>
<tr><td>End of session</td><td>Stop the Streamlit app (Ctrl+C). Remove values you no longer need from <code>.env</code> and never share that file.</td></tr>
<tr><td>Notebooks</td><td>Use Stop session when you finish; a running session keeps using capacity.</td></tr>
<tr><td>Paid capacity</td><td>If you used an F2 for an optional segment, <b>pause it</b> in the Azure portal. Pausing stops the meter.</td></tr></table>
<h2>8. Words to know</h2>
<table><tr><th style="width:36mm">Word</th><th>Meaning</th></tr>
<tr><td>Tenant</td><td>Your organization in Microsoft Entra ID.</td></tr>
<tr><td>Capacity</td><td>The compute you pay for (or the trial). Every Fabric engine draws from it.</td></tr>
<tr><td>Workspace</td><td>The container for items, with roles (Admin, Member, Contributor, Viewer).</td></tr>
<tr><td>Item</td><td>Anything you create: lakehouse, pipeline, notebook, model, report.</td></tr>
<tr><td>OneLake</td><td>The single lake under all items. Tables are Delta on Parquet.</td></tr>
<tr><td>Shortcut</td><td>A pointer to data that stays where it is; not a copy.</td></tr>
<tr><td>Medallion</td><td>Bronze (as arrived), silver (typed and cleaned), gold (ready to use).</td></tr>
<tr><td>Direct Lake</td><td>Power BI mode that reads the Delta tables directly: no import, no scheduled refresh.</td></tr>
<tr><td>Service principal</td><td>An identity for a program, such as the checkout app.</td></tr>
<tr><td>Holdout</td><td>Orders the model never trained on; used to score it honestly.</td></tr></table>
"""



# ------------------------------------------------------------------ DP-600 skills map
H, D, M, N = "Hands-on in a lab", "Shown in a demo", "Mentioned", "Not covered"
# (area, group, [(skill bullet of the study guide, lesson ids, level, note)])
DP600 = [
    ("Maintain a data analytics solution (25-30%)", "Implement security and governance", [
        ("Implement workspace-level access controls", ["1.3", "3.4"], H, "Roles shown in 1.3; Lab 4 gives a service principal the Contributor role."),
        ("Implement item-level access controls", ["2.9"], M, "Sharing is pointed at, not set up."),
        ("Implement row-level, column-level, object-level and file-level access control", [], N, ""),
        ("Apply sensitivity labels to items", ["2.11"], M, "Two sentences, no label is applied."),
        ("Endorse items", ["2.11"], D, "Promoted and Certified shown in item settings."),
    ]),
    ("Maintain a data analytics solution (25-30%)", "Maintain the analytics development lifecycle", [
        ("Configure version control for a workspace", ["2.11"], D, "The Git integration dialog is shown; nothing is connected."),
        ("Create and manage a Power BI Desktop project (.pbip)", [], N, ""),
        ("Create and configure deployment pipelines", ["2.11"], D, "The stage view is shown; no pipeline is built."),
        ("Perform impact analysis of downstream dependencies", ["2.11", "3.7"], H, "Lineage view of the project workspace in Lab 7."),
        ("Deploy and manage semantic models by using the XMLA endpoint", [], N, ""),
        ("Create and update reusable assets (.pbit, .pbids, shared semantic models)", [], N, ""),
    ]),
    ("Prepare data (45-50%)", "Get data", [
        ("Create a data connection", ["3.1", "3.6"], H, "HTTP connection in Lab 1; SQL database connection in Lab 6."),
        ("Discover data by using OneLake catalog and Real-Time hub", ["1.3", "2.6", "2.11"], D, ""),
        ("Ingest or access data as needed", ["2.1", "2.2", "3.1"], H, "Shortcuts and a Copy data pipeline in Lab 1; Dataflow Gen2 and Copy job are shown in 2.2."),
        ("Choose between different data stores", ["2.1", "2.4", "2.5"], D, "Lakehouse or warehouse is a topic of 2.4."),
        ("Implement OneLake integration for Eventhouse and semantic models", ["3.5"], M, "Optional OneLake availability step for the eventhouse only."),
    ]),
    ("Prepare data (45-50%)", "Transform data", [
        ("Create views, functions and stored procedures", ["3.5"], M, "A stored procedure appears as a fallback note; no views or functions."),
        ("Enrich data by adding new columns or tables", ["3.2"], H, "Feature columns and gold tables."),
        ("Implement a star schema for a lakehouse or warehouse", ["3.2", "2.4"], H, "Gold fact and four dimensions in the lakehouse (Lab 2)."),
        ("Denormalize data", [], N, ""),
        ("Aggregate data", ["3.2", "3.5"], H, ""),
        ("Merge or join data", ["3.2"], H, ""),
        ("Identify and resolve duplicate data, missing data or null values", ["3.1", "3.2"], H, "450 duplicate orders removed in Lab 2; null checks."),
        ("Convert column data types", ["3.2"], H, "Typed schemas for the silver tables."),
        ("Filter data", ["3.2", "3.5"], H, ""),
    ]),
    ("Prepare data (45-50%)", "Query and analyze data", [
        ("Select, filter and aggregate data by using the Visual query editor", ["2.4"], D, ""),
        ("Select, filter and aggregate data by using SQL", ["2.4", "3.2"], H, "T-SQL on the lakehouse endpoint in Lab 2; warehouse queries are shown in 2.4."),
        ("Select, filter and aggregate data by using KQL", ["3.5"], H, "KQL queryset and dashboard tiles."),
        ("Select, filter and aggregate data by using DAX", ["3.6"], M, "Ready-made measures are pasted and used; DAX is not taught."),
    ]),
    ("Implement and manage semantic models (25-30%)", "Design and build semantic models", [
        ("Choose a storage mode", ["2.9"], D, "Direct Lake against the older import mode."),
        ("Implement a star schema for a semantic model", ["3.6"], H, "Seven tables, relationships to four dimensions."),
        ("Implement relationships, such as bridge tables and many-to-many relationships", ["2.9", "3.6"], M, "Many-to-one relationships are built; bridge and many-to-many are not."),
        ("Write calculations that use DAX variables and functions", [], N, ""),
        ("Implement calculation groups, dynamic format strings and field parameters", [], N, ""),
        ("Identify use cases for and configure large semantic model storage format", [], N, ""),
        ("Design and build composite models", [], N, ""),
    ]),
    ("Implement and manage semantic models (25-30%)", "Optimize enterprise-scale semantic models", [
        ("Implement performance improvements in queries and report visuals", [], N, ""),
        ("Improve DAX performance", [], N, ""),
        ("Configure Direct Lake, including default fallback and refresh behavior", ["2.9", "3.6"], D, "A Direct Lake model is built in Lab 6; fallback settings are not covered."),
        ("Choose between Direct Lake on OneLake and Direct Lake on SQL analytics endpoint", ["3.6"], M, "One lab note says either works."),
        ("Implement incremental refresh for semantic models", [], N, "Incremental copy in a Copy job (2.2) is a different feature."),
    ]),
]


def dp600_counts():
    c = {H: 0, D: 0, M: 0, N: 0}
    for _a, _g, rows in DP600:
        for _s, _l, lev, _n in rows:
            c[lev] += 1
    return c


def skills_map_html():
    names = {l["num"]: l["name"] for l in CFG["lessons"]}
    cnt = dp600_counts()
    total = sum(cnt.values())
    cls = {H: "#1f8a4c", D: "#0b5cad", M: "#8a6d00", N: "#8a2f2f"}
    out = ['<div class="kicker">FABRIC · Build Real-Time AI on Microsoft Fabric</div><h1>How this project practises Exam DP-600 skills</h1>'
           '<p>Exam DP-600 (Implementing Analytics Solutions Using Microsoft Fabric) measures the skills listed below, as published by Microsoft on 19 October 2026. '
           'The table shows, skill by skill, which lessons of this course touch it and how deeply. Where the project does not practise a skill, it says so.</p>'
           '<table><tr><th style="width:44mm">Level</th><th>Meaning</th></tr>'
           f'<tr><td><b>{H}</b></td><td>You do it yourself, step by step, in a lab.</td></tr>'
           f'<tr><td><b>{D}</b></td><td>The trainer shows it on screen; no lab asks you to do it.</td></tr>'
           f'<tr><td><b>{M}</b></td><td>Named or explained in a few sentences; not practised.</td></tr>'
           f'<tr><td><b>{N}</b></td><td>Not in this course.</td></tr></table>']
    st = ("<style>table.sk{font-size:8pt;line-height:1.3;page-break-inside:auto;margin:0 0 3mm}table.sk td,table.sk th{padding:0.9mm 1.8mm}"
          "table.sk tr{page-break-inside:avoid}table.sk td.g{background:#e3eef0;color:#0b2a4a;font-weight:700}table.sk td.a{background:#0b2a4a;color:#fff;font-weight:700;font-size:8.6pt}"
          "table.sk tr:nth-child(even) td{background:transparent}table.sk td.g{background:#e3eef0!important}table.sk td.a{background:#0b2a4a!important}</style>")
    out.insert(0, st)
    body = ""
    last_area = None
    for area, group, rows in DP600:
        if area != last_area:
            body += f'<tr><td class="a" colspan="3">{html.escape(area)}</td></tr>'
            last_area = area
        body += f'<tr><td class="g" colspan="3">{html.escape(group)}</td></tr>'
        for skill, ids, lev, note in rows:
            les = "<br>".join(f"{i} {html.escape(names[i])}" for i in ids) if ids else "-"
            nt = f'<br><span style="font-weight:400;color:#4a5568">{html.escape(note)}</span>' if note else ""
            body += (f'<tr><td>{html.escape(skill)}</td><td>{les}</td>'
                     f'<td style="color:{cls[lev]};font-weight:600">{lev}{nt}</td></tr>')
    out.append(f'<table class="sk"><tr><th>Skill measured</th><th style="width:52mm">Lesson(s)</th><th style="width:50mm">Coverage</th></tr>{body}</table>')
    out.append(
        '<blockquote><p><b>An honest summary.</b> This project practises many DP-600 skills; it is not a complete exam-prep course. '
        'For the missing areas use the Microsoft Learn study guide: '
        '<a href="https://learn.microsoft.com/credentials/certifications/resources/study-guides/dp-600">learn.microsoft.com/credentials/certifications/resources/study-guides/dp-600</a>.</p>'
        f'<p>Of the {total} skills measured: <b>{cnt[H]}</b> hands-on in a lab, <b>{cnt[D]}</b> shown in a demo, <b>{cnt[M]}</b> mentioned, <b>{cnt[N]}</b> not covered.</p></blockquote>')
    return "".join(out)


# ------------------------------------------------------------------ slides
def slides_pdf(dest: Path):
    doc = pymupdf.open()
    for i in range(1, 6):
        img = FC / "slides" / "out" / f"S{i}.png"
        page = doc.new_page(width=960, height=540)
        page.insert_image(page.rect, filename=str(img))
    pdf = doc.tobytes()
    src = pymupdf.open(stream=pdf, filetype="pdf")
    n = len(src)
    flat = GW._flatten(src)
    for i, page in enumerate(flat, 1):
        t = f"FABRIC · slide S{i} · {i} / {n}"
        page.insert_text((24, 528), t, fontname="helv", fontsize=7, color=(0.7, 0.72, 0.75))
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(flat.tobytes(**GW._lock_opts()))
    print("  pdf", dest.name, f"{dest.stat().st_size // 1024} KB")


# ------------------------------------------------------------------ zips / lab files
LEAKS = [r"roohi", r"fabricuser", r"ab808e12", r"8bc31a35", r"b128d35a", r"@outlook\.com", r"@gennoor", r"\blosts\b",
         r"(?i)client_secret[ \t]*[=:][ \t]*['\"]?[A-Za-z0-9~._-]{12,}", r"sk-[A-Za-z0-9]{20}", r"InstrumentationKey=(?!\.\.\.|<)"]
TEXT_EXT = {".py", ".md", ".txt", ".json", ".example", ".kql", ".sql", ".dax", ".csv", ".ipynb", ".yaml", ".yml", ".toml", ".cfg", ".gitignore"}
SKIP_DIRS = {"__pycache__", ".pytest_cache", ".venv", ".nbdef", "mlruns", "generator"}
SKIP_FILES = {".env", "Thumbs.db", ".DS_Store"}


def scan_text(name: str, data: bytes) -> list[str]:
    if Path(name).suffix.lower() not in TEXT_EXT and not name.endswith(".example"):
        return []
    s = data.decode("utf-8", errors="ignore")
    s = s.replace("raw.githubusercontent.com/lostspace003/fabric-course", "raw.githubusercontent.com/REPO")   # the public course repo is intended
    return [p for p in LEAKS if re.search(p, s)]


def scrubbed_bytes(p: Path) -> bytes:
    suf = p.suffix.lower()
    if suf == ".ipynb":
        nb = json.loads(p.read_text(encoding="utf-8"))
        for c in nb["cells"]:
            s = scrub("".join(c["source"]))
            c["source"] = s.splitlines(keepends=True)
            if c["cell_type"] == "code":
                c["outputs"], c["execution_count"] = [], None
        return (json.dumps(nb, indent=1, ensure_ascii=False) + "\n").encode("utf-8")
    if suf in {".md", ".kql", ".sql", ".dax", ".py"}:
        return scrub(p.read_text(encoding="utf-8")).encode("utf-8")
    return p.read_bytes()


def stage_tree(pairs: list[tuple[Path, str]], dest: Path):
    """copy source files to dest\\<relative path>; returns list of problems"""
    problems = []
    for src, rel in pairs:
        if src.is_dir():
            for p in sorted(src.rglob("*")):
                if not p.is_file() or SKIP_DIRS & set(p.relative_to(src).parts) or p.name in SKIP_FILES or p.suffix == ".pyc":
                    continue
                r = f"{rel}/{p.relative_to(src).as_posix()}"
                data = scrubbed_bytes(p)
                if p.suffix.lower() in {".md", ".kql", ".sql", ".dax", ".py", ".ipynb"}:
                    problems += [f"{r}: {x}" for x in residue(data.decode('utf-8'))]
                problems += [f"{r}: {x}" for x in scan_text(p.name, data)]
                (dest / r).parent.mkdir(parents=True, exist_ok=True)
                (dest / r).write_bytes(data)
        else:
            data = scrubbed_bytes(src)
            if src.suffix.lower() in {".md", ".kql", ".sql", ".dax", ".py", ".ipynb"}:
                problems += [f"{rel}: {x}" for x in residue(data.decode('utf-8'))]
            problems += [f"{rel}: {x}" for x in scan_text(src.name, data)]
            (dest / rel).parent.mkdir(parents=True, exist_ok=True)
            (dest / rel).write_bytes(data)
    return problems


README_M2 = """# FABRIC - Module 2 - Student files

Files for the component demos in Module 2 (How Fabric Is Useful). Open the lessons, follow along in your own Fabric trial,
and use these files when a demo says "upload", "paste" or "run the course file".

## What is inside

- `data/reference/` - the small reference tables and the 5,000-order sample: `carriers.csv`, `warehouses.csv`, `regions.csv`,
  `calendar_raw.csv`, `orders_sample.csv` (lesson 2.1 uploads four of them; 2.2 reads `calendar_raw.csv` from the web).
- `data/ops/sqldb_ops_setup.sql` - creates `dbo.open_orders` and `dbo.risk_alerts` in the SQL database (lesson 2.5).
- `fabric/sql/warehouse_demo.sql` - the queries for the warehouse demo (lesson 2.4).
- `data/DATA_DICTIONARY.md`, `data/manifest.json` - every column and every file with its row count.

All data is synthetic: no real people, companies or addresses.

## Start here

1. Finish lesson 1.2 so that you have a Fabric trial, and lesson 1.3 so that `ws-fabric-tour` exists with its license mode set to Trial.
2. Follow lesson 2.1 first: later demos reuse `lh_reference`.
3. Never share a `.env` file or a secret. Nothing in this folder needs one.
"""

README_M3 = """# FABRIC - Module 3 - Student files

Everything for the Brightcart Delivery Promise project (labs 1 to 7 and the two optional segments).
Unzip it, open the folder in VS Code if you want to read the code, and follow the lab guides (PDF) with the lesson videos.

## What is inside

- `data/history/` - the five history files the pipeline lands in Lab 1: `customers.csv`, `orders.csv`, `shipments.csv`, `daily_ops.csv`, `weather_daily.csv`.
- `data/reference/`, `data/ops/` - the reference tables and the operational tables from Module 2 (also used by the fallback in Lab 1).
- `data/DATA_DICTIONARY.md`, `data/manifest.json` - columns, row counts and file hashes.
- `fabric/notebooks/` - `nb_00_bootstrap` (fallback if you skipped Module 2), `nb_01_bronze_to_silver`, `nb_02_features`, `nb_03_train`, `nb_04_batch_score`.
- `fabric/sql/`, `fabric/kql/`, `fabric/powerbi/` - T-SQL, KQL and DAX files that the labs paste from.
- `fabric/pipelines/`, `fabric/activator/` - click-by-click build notes for the pipelines and the Activator rule.
- `contracts/` - the 16-feature contract, the request and response samples and the event schema.
- `app/checkout-simulator/` - the Streamlit checkout app. It starts in mock mode, which needs no Fabric at all.
- `ops/` - the cost guardrails and the clean-up steps for the end of every session.

## Start here

1. Finish Modules 1 and 2 (or use the fallback in Lab 1, step 0).
2. For the app you need Python 3.11 or newer: `cd app/checkout-simulator`, `pip install -r requirements.txt`,
   copy `.env.example` to `.env` and run `streamlit run app.py`.
3. Never share your `.env` file or paste a secret into a notebook: it holds your own tenant, client and workspace values.
4. When you finish a session: deactivate endpoints, switch the schedule off, stop the Activator rule and the app (see `ops/` and the cheat sheet).
"""

README_PACK = """# FABRIC - Student files

One folder per module, plus four documents that belong to the whole course:

- **FABRIC - Course map and cheat sheet.pdf** - lessons, item names, the 16-feature contract, decision policy, numbers to expect, common errors, cost checklist
- **FABRIC - Slides S1-S5.pdf** - the five slides of the course
- **FABRIC - ML In one minute cards.pdf** - ten short cards on the machine-learning ideas the project uses
- **FABRIC - DP-600 skills map.pdf** - which Exam DP-600 skills the project practises, skill by skill, and which it does not

Inside the module folders:

- **Guides/** - the lab guides as PDF (Module 3)
- **Lab/** - the data, notebooks, queries and the checkout app, as in the module zip

The same files are available as one zip per module. Never share your own `.env` file.
"""


def make_zip(stage: Path, zip_path: Path, top: str):
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(stage.rglob("*")):
            if p.is_file():
                z.write(p, f"{top}/{p.relative_to(stage).as_posix()}")
    print("  zip", zip_path.name, f"{zip_path.stat().st_size / 1e6:.1f} MB")


def main():
    if PACK.exists():
        shutil.rmtree(PACK)
    TMP.mkdir(parents=True, exist_ok=True)
    SHIP.mkdir(parents=True, exist_ok=True)
    problems = []

    print("lab guides")
    g_dir = PACK / MODDIR[3] / "Guides"
    for rel, name in GUIDES.items():
        body, title, res = lab_guide_html(FC / "course" / rel)
        problems += [f"{name}: {x}" for x in res]
        write_pdf(body, g_dir / name, ("FABRIC · " + title).replace("→", "to"), name=Path(rel).name)
    print("cheat sheet, ML cards, slides")
    write_pdf(cheat_sheet_html(), PACK / "FABRIC - Course map and cheat sheet.pdf", "FABRIC · Course map and cheat sheet", name="cheat")
    write_pdf(ml_cards_html(), PACK / "FABRIC - ML In one minute cards.pdf", "FABRIC · ML: In one minute", landscape=True, name="mlcards")
    slides_pdf(PACK / "FABRIC - Slides S1-S5.pdf")
    write_pdf(skills_map_html(), PACK / "FABRIC - DP-600 skills map.pdf", "FABRIC · How this project practises Exam DP-600 skills", name="dp600")

    print("zips")
    d = FC / "data"
    m2 = [(d / "reference", "data/reference"), (d / "ops" / "sqldb_ops_setup.sql", "data/ops/sqldb_ops_setup.sql"),
          (d / "DATA_DICTIONARY.md", "data/DATA_DICTIONARY.md"), (d / "manifest.json", "data/manifest.json"),
          (FC / "fabric" / "sql" / "warehouse_demo.sql", "fabric/sql/warehouse_demo.sql")]
    m3 = [(d / "history", "data/history"), (d / "reference", "data/reference"), (d / "ops", "data/ops"),
          (d / "DATA_DICTIONARY.md", "data/DATA_DICTIONARY.md"), (d / "manifest.json", "data/manifest.json"),
          (FC / "fabric", "fabric"), (FC / "kit" / "contracts", "contracts"),
          (FC / "app" / "checkout-simulator", "app/checkout-simulator"),
          (FC / "ops" / "cost-guardrails.md", "ops/cost-guardrails.md"), (FC / "ops" / "cleanup.md", "ops/cleanup.md")]
    for n, pairs, readme, top in ((2, m2, README_M2, "fabric-module-2"), (3, m3, README_M3, "fabric-module-3")):
        stage = TMP / f"stage{n}"
        shutil.rmtree(stage, ignore_errors=True)
        problems += stage_tree(pairs, stage)
        (stage / "README.md").write_text(readme, encoding="utf-8")
        make_zip(stage, SHIP / f"FABRIC - Module {n} - Student files.zip", top)
        shutil.copytree(stage, PACK / MODDIR[n] / "Lab", dirs_exist_ok=True)
    (PACK / "README.md").write_text(README_PACK, encoding="utf-8")
    if problems:
        print("PROBLEMS (fix before shipping):")
        for p in problems:
            print("  ", p)
        sys.exit(2)
    size = sum(p.stat().st_size for p in PACK.rglob("*") if p.is_file())
    print(f"done: {PACK} {size // (1024 * 1024)} MB")


if __name__ == "__main__":
    main()
